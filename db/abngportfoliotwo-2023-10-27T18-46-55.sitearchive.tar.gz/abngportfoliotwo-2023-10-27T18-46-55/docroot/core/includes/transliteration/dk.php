<?php
/**
 * @file
 * Danish language transliteration overrides.
 */
$overrides['dk'] = array(
  0xC5 => 'Aa',
  0xD8 => 'Oe',
  0xE5 => 'aa',
  0xF8 => 'oe',
);
