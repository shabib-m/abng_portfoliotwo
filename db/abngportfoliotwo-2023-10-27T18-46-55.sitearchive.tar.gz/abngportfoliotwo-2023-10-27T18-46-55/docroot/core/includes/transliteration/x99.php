<?php

$base = array(
  0x00 => 'hai', 'ren', 'tian', 'jiao', 'jia', 'bing', 'yao', 'tong', 'ci', 'xiang', 'yang', 'juan', 'er', 'yan', 'le', 'xi',
  0x10 => 'can', 'bo', 'nei', 'e', 'bu', 'jun', 'dou', 'su', 'yu', 'shi', 'yao', 'hun', 'guo', 'shi', 'jian', 'zhui',
  0x20 => 'bing', 'xian', 'bu', 'ye', 'tan', 'fei', 'zhang', 'wei', 'guan', 'e', 'nuan', 'yun', 'hu', 'huang', 'tie', 'hui',
  0x30 => 'jian', 'hou', 'ai', 'tang', 'fen', 'wei', 'gu', 'cha', 'song', 'tang', 'bo', 'gao', 'xi', 'kui', 'liu', 'sou',
  0x40 => 'tao', 'ye', 'yun', 'mo', 'tang', 'man', 'bi', 'yu', 'xiu', 'jin', 'san', 'kui', 'zhuan', 'shan', 'chi', 'dan',
  0x50 => 'yi', 'ji', 'rao', 'cheng', 'yong', 'tao', 'wei', 'xiang', 'zhan', 'fen', 'hai', 'meng', 'yan', 'mo', 'chan', 'xiang',
  0x60 => 'luo', 'zan', 'nang', 'shi', 'ding', 'ji', 'tuo', 'tang', 'tun', 'xi', 'ren', 'yu', 'chi', 'fan', 'yin', 'jian',
  0x70 => 'shi', 'bao', 'si', 'duo', 'yi', 'er', 'rao', 'xiang', 'he', 'le', 'jiao', 'xi', 'bing', 'bo', 'dou', 'e',
  0x80 => 'yu', 'nei', 'jun', 'guo', 'hun', 'xian', 'guan', 'cha', 'kui', 'gu', 'sou', 'chan', 'ye', 'mo', 'bo', 'liu',
  0x90 => 'xiu', 'jin', 'man', 'san', 'zhuan', 'nang', 'shou', 'kui', 'guo', 'xiang', 'fen', 'bo', 'ni', 'bi', 'bo', 'tu',
  0xA0 => 'han', 'fei', 'jian', 'an', 'ai', 'fu', 'xian', 'yun', 'xin', 'fen', 'pin', 'xin', 'ma', 'yu', 'feng', 'han',
  0xB0 => 'di', 'tuo', 'zhe', 'chi', 'xun', 'zhu', 'zhi', 'pei', 'xin', 'ri', 'sa', 'yun', 'wen', 'zhi', 'dan', 'lu',
  0xC0 => 'you', 'bo', 'bao', 'jue', 'tuo', 'yi', 'qu', 'pu', 'qu', 'jiong', 'po', 'zhao', 'yuan', 'pei', 'zhou', 'ju',
  0xD0 => 'zhu', 'nu', 'ju', 'pi', 'zang', 'jia', 'ling', 'zhen', 'tai', 'fu', 'yang', 'shi', 'bi', 'tuo', 'tuo', 'si',
  0xE0 => 'liu', 'ma', 'pian', 'tao', 'zhi', 'rong', 'teng', 'dong', 'xun', 'quan', 'shen', 'jiong', 'er', 'hai', 'bo', 'zhu',
  0xF0 => 'yin', 'luo', 'zhou', 'dan', 'xie', 'liu', 'ju', 'song', 'qin', 'mang', 'lang', 'han', 'tu', 'xuan', 'tui', 'jun',
);
